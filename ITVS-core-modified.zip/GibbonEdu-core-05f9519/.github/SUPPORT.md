Installation & Support
======================
For installation instructions, visit [https://gibbonedu.org/support/administrators/installing-gibbon](https://gibbonedu.org/support/administrators/installing-gibbon).

For support visit [https://gibbonedu.org/support](https://gibbonedu.org/support).