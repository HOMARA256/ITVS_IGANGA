<p align="center">
    <a href="https://gibbonedu.org/" target="_blank"><img width="200" src="https://gibbonedu.org/img/gibbon-logo.png"></a><br>
    ITVS is a flexible, open source school management platform designed <br>
    to make life better for teachers, students, parents and schools.
</p>

------

ITVS Core
===========
The Core repository represents the bulk of ITVS, including all of its primary functionality. The core can be extended through the use of modules and themes, which are provided separately. See the [Extend](https://gibbonedu.org/extend/) page for more info.

ITVS is open source, and maintained for the benefit of teachers, students, parents and schools.

## Documentation

For full documentation, visit [docs.gibbonedu.org](https://docs.gibbonedu.org).

## Installation & Support

For installation instructions, visit [Getting Started: Installing ITVS](https://docs.gibbonedu.org/introduction/installing-gibbon)

For support visit [ask.gibbonedu.org](https://ask.gibbonedu.org) or see [our documentation](https://docs.gibbonedu.org).

## Cutting Edge
If you want to run the latest version of ITVS, prerelease, you can get the source from our [GitHub repository](https://github.com/ITVSEdu/core). Remember, though, it is not stable, and you may lose data. This is not for the faint of heart.

For installation instructions, be sure to follow the instructions for [Cutting Edge Code](https://docs.gibbonedu.org/introduction/installation-options/cutting-edge-code).

## Translation

Thanks to our amazing volunteers, ITVS is available in many different languages. We use the online tool [POEditor](https://poeditor.com), which enables our volunteer translators to collaborate and track their translation progress. Huge thanks to POEditor for their support of open source projects and making this tool available for our community. If you would like to help translate ITVS, please email support@gibbonedu.org and [learn more here](https://gibbonedu.org/about/#languages). Your help would be most appreciated!

## Contributing

We welcome community contribution and aim to ensure ITVS is an open and friendly environment. Information about contributing, submitting issues, and pull requests can be found in the following docs:

- [**Contributor Guide**](https://github.com/ITVSEdu/core/blob/master/.github/CONTRIBUTING.md) - Learn more about how you can contribute to ITVS, from code to non-code contributions alike.

- [**Code of Conduct**](https://github.com/ITVSEdu/core/blob/master/.github/CODE_OF_CONDUCT.md) - Our pledge to foster a welcoming community and a positive environment for anyone to participate in.

- [**Developer Workflow**](https://docs.gibbonedu.org/development/getting-started/developer-workflow) - If you want to get involved in the development process, check out our workflow and [GitHub repository](https://github.com/ITVSEdu/core). Generally there will be a development branch with the latest code, as per our [Development Road Map](https://docs.gibbonedu.org/development/gibbon-road-map).

## License

ITVS is licensed under GNU General Public License v3.0. You can obtain a copy of the license [here](https://github.com/ITVSEdu/core/blob/master/LICENSE).
